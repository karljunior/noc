<?php include("../bd/conectar.php"); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Cadastrar Voos</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
	<?php 
        $cpf = $_GET["cpf"];
        $dados = $_GET["id"];
		
		$selnome=mysql_query('select UPPER(nomecli) as nomecli from cliente where cpf='.$cpf);
		$resnome=mysql_fetch_array($selnome);
        
		/* "
		select idcontrato, cpf, aerea_cia_ida, voo_num_ida, voo2_num_2_ida, embarq_data_ida, partida_hora_ida, desemb_data_ida, chegada_hora_ida, loc_ida, obs_ida, dia_traslado_ida, hora_ida, aerea_cia_volta, voo_num_volta, voo2_num_volta, embarq_data_volta, partida_hora_volta, desemb_data_volta, chegada_hora_volta, loc_volta, obs_volta, dia_traslado_volta, hora_volta 
from dados_voos
		
		" */
		
        $select=mysql_query('select * from dados_voos where cpf='.$cpf.' and idcontrato='.$dados);
			 
		/* echo "select idcontrato, cpf, aerea_cia_ida, voo_num_ida, voo2_num_2_ida, embarq_data_ida, partida_hora_ida, desemb_data_ida, chegada_hora_ida, loc_ida, obs_ida, dia_traslado_ida, hora_ida, aerea_cia_volta, voo_num_volta, voo2_num_volta, embarq_data_volta, partida_hora_volta, desemb_data_volta, chegada_hora_volta, loc_volta, obs_volta, dia_traslado_volta, hora_volta
			 from dados_voos where cpf='".$cpf."' and idcontrato=".$dados; */
        $ressel=mysql_fetch_array($select);
		
		/* echo "<br> Resultado do select: CIA AEREA IDA:".$ressel['aerea_cia_ida']; */
		

		
		
		$sel_dados_contrato=mysql_query("SELECT UPPER(cli.nomecli) as nomecli,cli.dtnasc,
			cli.cpf,concat(mid(cli.cpf,1,3),'.',mid(cli.cpf,4,3),'.',mid(cli.cpf,7,3),'-',mid(cli.cpf,10,2)) as cpfformatado,
			cli.rg,cli.telres,cli.telcel,UPPER(cli.email) as email,UPPER(cli.endres) as endres,cli.numres,
			UPPER(cli.complres) as complres,UPPER(cli.bairrores) as bairrores,UPPER(cli.cidaderes) as cidaderes, 
			cli.cepres,UPPER(cli.filiacaopai) as filiacaopai,UPPER(cli.filiacaomae) as filiacaomae, UPPER(cli.empresa) as empresa,
			UPPER(cli.cargo) as cargo,UPPER(cli.endcom) as endcom,cli.numcom,UPPER(cli.complcom) as complcom,
			UPPER(cli.bairrocom) as bairrocom,UPPER(cli.cidadecom) as cidadecom,cli.cepcom,cli.telcom,cli.ramalcom,
			UPPER(cli.banco) as banco,cli.agencia,cli.cc,cli.ufres,ufr.sigla as ufres,cli.exp,ufrg.sigla as rgexp,cli.ufcom,
			ufc.sigla as ufcom,replace( replace( replace( format((c.difpagamento), 2), '.', '|'), ',', '.'), '|', ',') as fmt_difpagamento,
			c.difpagamento,replace( replace( replace( format((c.entrada), 2), '.', '|'), ',', '.'), '|', ',') as fmt_entrada,
			c.entrada,replace( replace( replace( format((c.valorcontrato), 2), '.', '|'), ',', '.'), '|', ',') as fmt_valorcontrato,
			c.valorcontrato,UPPER(c.bandeira_cartao) as bandeira_cartao,c.ciente,c.datavoo,c.idtipopagto,UPPER(c.nometitular) as nometitular,
			c.numcartao,c.qtdparcelas,c.validade,UPPER(aero_ida.nome_aeroporto) as vaucher_ida,UPPER(aero_volta.nome_aeroporto) as vaucher_volta,
			UPPER(uf_saida.sigla) as localsaida,tipo.idtipo,UPPER(tipo.desctipo) as desctipo,traslado_ida.id_data_traslado,
			concat(traslado_ida.dia,' ',traslado_ida.horario) as traslado_ida,
			traslado_volta.id_data_traslado,concat(traslado_volta.dia,' ',traslado_volta.horario) as traslado_volta,
			date_format(c.data_ida,'%d/%m/%Y') as data_ida,c.id_aeroporto_ida,UPPER(aida.nome_aeroporto) as aeroporto_ida,
			date_format(c.data_volta,'%d/%m/%Y') as data_volta,c.id_aeroporto_volta,UPPER(avolta.nome_aeroporto) as aeroporto_volta,
			UPPER(r.nomerepresentante) as nomerepresentante,UPPER(c.codpromocao) as codpromocao,UPPER(c.vendedor) as vendedor
			From contrato c
			inner join cliente cli on cli.cpf = c.cpf
			left join tipo on tipo.idtipo = c.idtipo
			left join uf ufr on cli.ufres = ufr.id_uf
			inner join uf ufrg on cli.exp = ufrg.id_uf
			left join uf ufc on cli.ufcom = ufc.id_uf
			left join vaucher on c.id_vaucher = vaucher.id_vaucher
			left join aeroporto aero_ida on vaucher.id_aeroporto_ida = aero_ida.id_aeroporto
			left join aeroporto aero_volta on vaucher.id_aeroporto_volta = aero_volta.id_aeroporto
			left join uf uf_saida on aero_ida.id_uf = uf_saida.id_uf
			left join data_traslado traslado_ida on c.idtraslado_ida = traslado_ida.id_data_traslado and traslado_ida.tipo_traslado = 0
			left join data_traslado traslado_volta on c.idtraslado_volta = traslado_volta.id_data_traslado and traslado_volta.tipo_traslado = 1
			inner join aeroporto aida on aida.id_aeroporto = c.id_aeroporto_ida
			left join aeroporto avolta on avolta.id_aeroporto = c.id_aeroporto_volta
			left join representante r on r.idrepresentante = c.idrepresentante
			WHERE c.idcontrato=".$dados);
			$dados_contrato=mysql_fetch_array($sel_dados_contrato);
			
			

     ?>
	<div class="principal">
  		<h3>Cadastro de Voos dos passageiros</h3>
        <form action="atualiza.php?tipo=1" method="post" name="formdados">
            <table cellpadding="5">
            	<tr>
                	<td><label>Grupo:</label>
                    	<input name="idcontrato" type="text" size="15" maxlength="15" value="<?=$dados?>" /><br /></td>
                    <td><label>CPF:</label>
                    	<input name="cpf" type="text" size="15" maxlength="15" value="<?=$cpf?>"/><br /></td></tr>
				<tr><td colspan="2"><?=$resnome['nomecli'] ?></td></tr>
            	<tr>
                	<td colspan="2"><h2>Dados Voo Ida</h2></td></tr>
                <tr>
                	<td><label>A&eacute;rea Cia: </label>
                    	<input name="aerea_cia_ida" type="text" id="aerea_cia_ida" size="15" maxlength="15" value="<?=$ressel["aerea_cia_ida"]?>" /></td>
                    <td><label>V&ocirc;o N&ordm;: </label>
                    	<input name="voo_num_ida" type="text" size="15" maxlength="15" value="<?=$ressel["voo_num_ida"]?>" /></td></tr>
                <tr>
					<td><label>V&ocirc;o N&ordm;2: </label>
                    	<input name="voo2_num_2_ida" type="text" size="15" maxlength="15" value="<?=$ressel["voo2_num_2_ida"]?>" /></td>
                    <td><label>Embarq Data: </label>
                    	<input name="embarq_data_ida" type="text" size="10" maxlength="10" value="<?=$ressel["embarq_data_ida"]?>" /></td></tr>
                <tr>
                    <td><label>Origem: 
                        <input name="origem" type="text" size="20" maxlength="20" readonly="true" value="<?=$dados_contrato['aeroporto_ida'] ?>" />
                    </label></td>
                    <td><label>Partida Local: 
                      <input name="partida_local_ida" type="text" id="partida_local_ida" value="<?=$ressel["partida_local_ida"]?>" />
                    </label></td></tr>
               <tr>
					<td><label>Partida Hora: </label>
                      <input name="partida_hora_ida" type="text" size="5" maxlength="5" value="<?=$ressel["partida_hora_ida"]?>" /></td>
                    <td><label>Desembarque Data: </label>
                      <input name="desemb_data_ida" type="text" size="10" maxlength="10" value="<?=$ressel["desemb_data_ida"]?>" /></td></tr>
               <tr>
               		<td><label>Chegada Local: </label>
                      <input name="chegada_local_ida" type="text" size="20" maxlength="20" readonly="true" value="SSA" /></td>
                    <td><label>Chegada Hora: </label>
                      <input name="chegada_hora_ida" type="text" size="5" maxlength="5" value="<?=$ressel["chegada_hora_ida"]?>" /></td></tr>
				<tr>
                	<td><label>Loc: </label>
                      <input name="loc_ida" type="text" size="15" maxlength="15" value="<?=$ressel["loc_ida"]?>" /></td>
                    <td><label>Data emiss&atilde;o ida: </label>
                    <input name="dt_emis_ida" type="text" value="<?=$ressel["dt_emis_ida"]?>" size="10" maxlength="10" /></td></tr>
				<tr>
                	<td colspan="2"><p align="center">Observa��es ida:<br />
                	<textarea name="obs_ida" cols="83" rows="3"><?=$ressel["obs_ida"]?></textarea>
              	    </p></td></tr>
				<tr>
                	<td><label>Tarifa Valor - EMITIDO: </label><input name="tarifa_valor_emitido_ida" type="text" value="<?=$ressel["tarifa_valor_emitido_ida"]?>" size="15" maxlength="15" /></td>
                    <td><label> Valor A&eacute;reo Venda: </label><input name="valor_aereo_venda_ida" type="text" value="<?=$ressel["valor_aereo_venda_ida"]?>" size="15" maxlength="15" /></td></tr>
				<tr>
                	<td><label>C&oacute;digo Traslado:
<input name="codigo_traslado" type="text" id="codigo_traslado" value="<?=$ressel["codigo_traslado"]?>" size="15" maxlength="15" />
                	</label></td>
                    <td><label></label>
                  <label>&Ocirc;nibus:
<input name="onibus" type="text" id="onibus" value="<?=$ressel["onibus"]?>" size="30" maxlength="50" />
                  </label></td></tr>
				<tr>
				  <td><label>Dia TRASLADO: </label>
                    <input name="dia_traslado_ida" type="text" size="10" maxlength="10" value="<?=$ressel["dia_traslado_ida"]?>" /></td>
				  <td><label>Hora: </label>
                    <input name="hora_ida" type="text" size="5" maxlength="5" value="<?=$ressel["hora_ida"]?>" /></td>
			  </tr>
				<tr>
                	<td><label>Valor Traslado: </label><input name="valor_traslado" type="text" value="<?=$ressel["valor_traslado"]?>" size="15" maxlength="15" /></td>
                    <td><label>Tipo de Pacote: </label><input name="tipo_de_pacote" type="text" id="tipo_de_pacote" value="<?=$ressel["tipo_de_pacote"]?>" size="20" maxlength="50" /></td></tr>
				<tr>
                	<td><label>Total: </label><input name="total_ida" type="text" value="<?=$ressel["total_ida"]?>" size="15" maxlength="15" /></td>
                    <td><label>N Conv: </label>
                    <input name="n_conv" type="text" value="<?=$ressel["n_conv"]?>" size="15" maxlength="40" /></td></tr>
				<tr>
                	<td><label>Convite: </label><input name="convite" type="text" value="<?=$ressel["convite"]?>" size="15" maxlength="15" /></td>
                    <td><label>Forma de Pagamento: </label><input name="forma_de_pagamento" type="text" value="<?=$ressel["forma_de_pagamento"]?>" size="15" maxlength="30" /></td></tr>
				<tr>
                	<td><label>Representante: </label><input name="representante" type="text" value="<?=$ressel["representante"]?>" size="15" maxlength="50" /></td>
                    <td><label>X</label><input name="x" type="text" value="<?=$ressel["x"]?>" size="15" maxlength="50" /></td></tr>
                    
				<tr><td colspan="2"><h2>Dados Voo Volta</h2></td></tr>
				<tr>
                	<td><label>A&eacute;rea Cia: </label>
                    	<input name="aerea_cia_volta" type="text" size="15" maxlength="15" value="<?=$ressel["aerea_cia_volta"]?>" /></td>
                    <td><label>V&ocirc;o N&ordm;: </label>
                    	<input name="voo_num_volta" type="text" size="15" maxlength="15" value="<?=$ressel["voo_num_volta"]?>" /></td></tr>
				<tr>
                	<td><label>V&ocirc;o N&ordm;2: </label>
                    	<input name="voo2_num_volta" type="text" size="15" maxlength="15" value="<?=$ressel["voo2_num_volta"]?>" /></td>
                    <td><label>Embarque Data: </label>
                    	<input name="embarq_data_volta" type="text" size="10" maxlength="10" value="<?=$ressel["embarq_data_volta"]?>" /></td></tr>
				<tr>
                	<td><label>Partida Local: </label>
                    	<input name="partida_local_volta" type="text" size="20" maxlength="20" readonly="true" value="SSA" /></td>
                    <td><label>Partida Hora: </label>
                    	<input name="partida_hora_volta" type="text" size="5" maxlength="5" value="<?=$ressel["partida_hora_volta"]?>" /></td></tr>
				<tr>
                	<td><label>Desembarque Data: </label>
                    	<input name="desemb_data_volta" type="text" size="10" maxlength="10" value="<?=$ressel["desemb_data_volta"]?>" /></td>
                    <td><label>Chegada Local: </label>
                    	<input name="chegada_local_volta" type="text" size="20" maxlength="20" value="<?=$ressel["chegada_local_volta"]?>" /></td></tr>
				<tr>
                	<td><label>Chegada Hora: </label>
                    	<input name="chegada_hora_volta" type="text" size="5" maxlength="5" value="<?=$ressel["chegada_hora_volta"]?>" /></td>
                    <td><label>Loc: </label>
                    	<input name="loc_volta" type="text" size="15" maxlength="15" value="<?=$ressel["loc_volta"]?>" /></td></tr>
				<tr>
                	<td><label>Dt emiss: </label><input name="dt_emis_volta" type="text" value="<?=$ressel["dt_emis_volta"]?>" size="10" maxlength="10" /></td>
                    <td><label></label></td></tr>
				<tr>
				  <td colspan="2" align="center"><label>Observa��es volta:</label><br />
				      <textarea name="obs_volta" cols="83" rows="3" id="obs_volta"><?=$ressel["obs_volta"]?></textarea></td>
			  </tr>
				<tr>
                	<td><label>Tarifa Valor EMITIDO: </label><input name="tarifa_valor_emitido_volta" type="text" value="<?=$ressel["tarifa_valor_emitido_volta"]?>" size="15" maxlength="15" /></td>
                    <td><label>Valor A&eacute;reo Venda: </label><input name="valor_aereo_venda_volta" type="text" value="<?=$ressel["valor_aereo_venda_volta"]?>" size="15" maxlength="15" /></td></tr>
				<tr>
                	<td><label>Dia Traslado: </label>
                    	<input name="dia_traslado_volta" type="text" size="10" maxlength="10" value="<?=$ressel["dia_traslado_volta"]?>" /></td>
                    <td><label>Hora: </label>
                    	<input name="hora_volta" type="text" size="5" maxlength="5" value="<?=$ressel["hora_volta"]?>" /></td></tr>
				<tr>
				  <td>Valor Traslado: 
			      <input name="valor_traslado_volta" type="text" id="valor_traslado_volta" value="<?=$ressel["valor_traslado_volta"]?>" size="10" maxlength="10" /></td>
			      <td>Pagto volta: 
		          <input name="pagto_volta" type="text" id="pagto_volta" value="<?=$ressel["pagto_volta"]?>" size="10" maxlength="10" /></td>
			  </tr>
				<tr>
				  <td colspan="2"><label>				    Observa&ccedil;&otilde;es:<br />
                    </label>
                    <div align="center">
                      <textarea name="obs_volta2" cols="83" rows="3"><?=$ressel["obs_volta"]?></textarea>
                  </div></td>
			  </tr>
				<tr>
                	<td><label>Total: </label><input name="total" type="text" value="<?=$ressel["total"]?>" size="15" maxlength="15" /></td>
                	<td><label>Conv volta: </label>
               	    <input name="conv_volta" type="text" id="conv_volta" value="<?=$ressel["conv_volta"]?>" size="15" maxlength="15" /></td>
				</tr>
                <tr>
                  <td><label>email representante: </label>
                  <input name="email_representante" type="text" id="email_representante" value="<?=$ressel["email_representante"]?>" size="15" maxlength="15" /></td>
                  <td><label>Cott volta: </label>
                  <input name="cott_volta" type="text" id="cott_volta" value="<?=$ressel["cott_volta"]?>" size="15" maxlength="15" /></td>
                </tr>
                <tr><td colspan="2"><div id="contrato">
                <input name="dados_completos" type="checkbox" <? if ($ressel["dados_completos"]=='on') { ?>  checked="checked" <? } ?>/>  
                Liberado?</div></td></tr> 
                <tr>
                	<td colspan="2">
                    	<div align="center">
                   	    <input name="voltar" type="button" class="botaoform" onclick="javascript:history.go(-1)" value="Voltar" />
                   	  | 
                        <input name="enviar" type="submit" class="botaoform" value="Salvar" />
                    	</div></td></tr>
			</table>
   	  </form>
    <br />
    </div>
</body>
</html>
