<?php include('../bd/conectar.php') ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Buscar passageiros</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />


</head>
<body>
    <div class="principal" >
		<?php 
        
        $dados = $_GET[dados];
        
        /* echo 'select UPPER(nomecli) as nomecli, cpf, rg, dtnasc
        from cliente cli
        left join passxcontrato on passxcontrato.cpf = cli.cpf
        left join contrato on contrato.cpf = cli.cpf
        where contrato.idcontrato = '.$dados.' and flagpassageiro = 1
        or passxcontrato.idcontrato = '.$dados.' order by nomecli'; */
        
        
        $res_busca=mysql_query("select UPPER(nomecli) as nomecli, cli.cpf as cpf, cli.rg as rg, cli.dtnasc as dtnasc
        from cliente cli
        left join passxcontrato on passxcontrato.cpf = cli.cpf
        left join contrato on contrato.cpf = cli.cpf
        where contrato.idcontrato = ".$dados." and flagpassageiro = 1
        or passxcontrato.idcontrato = ".$dados." order by nomecli");
        $qtde_passageiros=mysql_num_rows($res_busca);
        
        echo '<h3>N&uacute;mero do contrato: '.$dados.'</h3>';
        echo '
        <table class="wide-table" border="1" cellpadding="4" cellspacing="0">
        
            <tr>
                <td width="330" valign="middle"><b>Nome</b></td>
                <td width="120" nowrap="nowrap" valign="middle"><b>CPF</b></td>
                <td width="100" nowrap="nowrap" valign="middle"><b>RG</b></td>
                <td width="100" nowrap="nowrap" valign="middle"><b>Dt. Nasc</b></td>
                <td>&nbsp;</td>
            </tr>';
            /*Carregar passageiros na tabela--> <!-- DADOS DOS PASSAGEIROS -->*/
            while($escrever=mysql_fetch_array($res_busca))
            {
                echo '
                <tr>
                    <td width="330" valign="middle">'.$escrever[nomecli].'</td>
                    <td width="120" nowrap="nowrap" valign=\"middle\">'.$escrever[cpf].'</td>
                    <td width="100" nowrap="nowrap" valign=\"middle\">'.$escrever[rg].'</td>
                    <td width="100" nowrap="nowrap" valign=\"middle\">'.$escrever[dtnasc].'</td>
                    <td width="55" nowrap="nowrap" valign=\"middle\"><a href="modificar_voos.php?cpf='.$escrever[cpf].'&id='.$dados.'"><img src="img/voos.png"></a></td>
                </tr>';
            }
            echo '<tr> <td colspan="5">Total de passageiros encontrados: '.$qtde_passageiros.' </td></tr> </table>';
        ?>
   		<div><br />| <input name="voltar" type="button" class="botaoform" onclick="javascript:location='cadastro_voos.php?dados=<?=$dados?>'" value="Voltar" /> |<br />&nbsp;</div>
    </div>
</body>
</html>