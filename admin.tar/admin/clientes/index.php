<?php include('../../bd/conectar_hmg.php') ?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <title>Administrando Clientes</title>
        <link href="css/css.css" rel="stylesheet" type="text/css" />
    </head>

    <body>
        <div class="principal">
            <?php
            // Defina o numero de registros exibidos por p�gina.
            $num_por_pagina = 10;

            // Descubra o n�mero da p�gina que ser� exibida.
            $pagina = $_GET['pagina'];
            // Se o numero da p�gina n�o for informado, definir como 1
            if (!$pagina) {
                $pagina = 1;
            }

            // Definir o n�mero do primeiro registro da p�gina. Fa�a a continha na calculadora que voc� entender� minha f�rmula.
            $primeiro_registro = ($pagina * $num_por_pagina) - $num_por_pagina;


            // Consulta apenas os registros da p�gina em quest�o utilizando como aux�lio a defini��o LIMIT. Ordene os registros.
            $cpf_cliente = $_GET[cpf];
            if ($cpf_cliente) {
                $script_select.="SELECT UPPER( nomecli ) AS nomecli, cpf, rg, dtnasc FROM cliente where cpf=$cpf_cliente";
            } else {
                $script_select.="SELECT UPPER( nomecli ) AS nomecli, cpf, rg, dtnasc FROM cliente LIMIT $primeiro_registro, $num_por_pagina";
            }
            $res_busca = mysql_query($script_select);
            $qtde_passageiros = mysql_num_rows($res_busca);

            echo '<h3>LISTA DOS CLIENTES CADASTRADOS NA BASE...</h3><br />';
            echo '
			<table id="alter" border="1" cellpadding="5px" cellspacing="0">
				<tr>
					<th ><b>Nome</b></td>
					<th ><b>CPF</b></td>
					<th ><b>RG</b></td>
					<th ><b>Dt. Nasc</b></td>
					<th>&nbsp;</td>
				</tr>';

            $cont = 1;
            /* Carregar passageiros na tabela--> <!-- DADOS DOS PASSAGEIROS --> */
            while ($escrever = mysql_fetch_array($res_busca)) {
                $resto = ($cont % 2);
                if ($resto == 0) {
                    $var_tr = " class=\"dif\"";
                } else {
                    $var_tr = " ";
                }

                echo '
					<tr' . $var_tr . '>
						<td >' . $escrever[nomecli] . '</td>
						<td >' . $escrever[cpf] . '</td>
						<td >' . $escrever[rg] . '</td>
						<td >' . $escrever[dtnasc] . '</td>
						<td ><a href="#">#</a></td>
					</tr>';
                $cont++;
            }
            echo ' </table>';

            // bloco 6 - construa e exiba um painel de navegabilidade entre as p�ginas
            $consulta2 = "SELECT COUNT(*) FROM cliente";
            list($total_usuarios) = mysql_fetch_array(mysql_query($consulta2));

            $total_paginas = ($total_usuarios / $num_por_pagina);

            $prev = $pagina - 1;
            $next = $pagina + 1;
            // se p�gina maior que 1 (um), ent�o temos link para a p�gina anterior
            if ($pagina > 1) {
                $prev_link = "<a href=\"" . $PHP_SELF . "?pagina=" . $prev . "\">Anterior</a>";
            } else { // sen�o n�o h� link para a p�gina anterior
                $prev_link = "Anterior";
            }

            // se n�mero total de p�ginas for maior que a p�gina corrente, ent�o temos link para a pr�xima p�gina
            if ($total_paginas > $pagina) {
                $next_link = "<a href=\"" . $PHP_SELF . "?pagina=" . $next . "\">Pr�xima";
            } else { // sen�o n�o h� link para a pr�xima p�gina
                $next_link = "Pr�xima";
            }

            // vamos arredondar para o alto o n�mero de p�ginas que ser�o necess�rias para exibir todos os registros. Por exemplo, se temos 20 registros e mostramos 6 por p�gina, nossa vari�vel $total_paginas ser� igual a 20/6, que resultar� em 3.33. Para exibir os 2 registros restantes dos 18 mostrados nas primeiras 3 p�ginas (0.33), ser� necess�ria a quarta p�gina. Logo, sempre devemos arredondar uma fra��o de n�mero real para um inteiro de cima e isto � feito com a fun��o ceil().
            $total_paginas = ceil($total_paginas);
            $painel = "";
            for ($x = 1; $x <= $total_paginas; $x++) {
                if ($x == $pagina) { // se estivermos na p�gina corrente, n�o exibir o link para visualiza��o desta p�gina
                    $painel .= " [" . $x . "] ";
                } else {
                    $painel .= " <a href=\"" . $PHP_SELF . "?pagina=" . $x . "\">[" . $x . "]</a>";
                }
            }


            // exibir painel na tela
            echo " " . $prev_link . " | " . $painel . " | " . $next_link;
            ?>
            <div><br />&nbsp;<br /></div>
        </div>
    </body>
</html>
