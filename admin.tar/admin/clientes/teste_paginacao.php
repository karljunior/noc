<?php include("../../bd/conectar.php"); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-9959-1" />
<title>Untitled Document</title>
</head>

<body>
<? 
/* // bloco 1 - conecte-se ao banco de dados
$con = mysql_pconnect('localhost','brorient','170183cle'); // host, usuário, senha
mysql_select_db('brorient_broriente'); // banco de dados */


// bloco 2 - defina o número de registros exibidos por página
$num_por_pagina = 10;

// bloco 3 - descubra o número da página que será exibida
// se o numero da página não for informado, definir como 1
$pagina=$_GET['pagina'];
if (!$pagina) {
   $pagina = 1;
}


// bloco 4 - construa uma cláusula SQL "SELECT" que nos retorne somente os registros desejados
// definir o número do primeiro registro da página. Faça a continha na calculadora que você entenderá minha fórmula.
$primeiro_registro = ($pagina*$num_por_pagina) - $num_por_pagina;

// consulta apenas os registros da página em questão utilizando como auxílio a definição LIMIT. Ordene os registros pela quantidade de pontos, começando do maior para o menor DESC.
$consulta = "SELECT UPPER( nomecli ) AS nomecli, cpf, rg, dtnasc FROM cliente LIMIT ".$primeiro_registro.", ".$num_por_pagina;
// executar query
$res = mysql_query($consulta);


// bloco 5 - exiba os registros na tela
echo '<h3>LISTA DOS CLIENTES CADASTRADOS NA BASE...</h3><br />';
echo '<table id="alter" border="1" cellpadding="5px" cellspacing="0">
	<tr>
		<th ><b>Nome</b></td>
		<th ><b>CPF</b></td>
		<th ><b>RG</b></td>
		<th ><b>Dt. Nasc</b></td>
		<th>&nbsp;</td>
	</tr>';

while ($escrever=mysql_fetch_array($res)) {
echo '
	<tr>
		<td >'.$escrever["nomecli"].'</td>
		<td >'.$escrever["cpf"].'</td>
		<td >'.$escrever["rg"].'</td>
		<td >'.$escrever["dtnasc"].'</td>
		<td ><a href="#">#</a></td>
	</tr>';
}
echo "</table>";


// bloco 6 - construa e exiba um painel de navegabilidade entre as páginas
$consulta2 = "SELECT COUNT(*) FROM cliente";
list($total_usuarios) = mysql_fetch_array(mysql_query($consulta2));

$total_paginas = $total_usuarios/$num_por_pagina;

$prev = $pagina - 1;
$next = $pagina + 1;
// se página maior que 1 (um), então temos link para a página anterior
if ($pagina > 1) {
$prev_link = "<a href=\"".$PHP_SELF."?pagina=".$prev."\">Anterior</a>";
} else { // senão não há link para a página anterior
$prev_link = "Anterior";
}

// se número total de páginas for maior que a página corrente, então temos link para a próxima página
if ($total_paginas > $pagina) {
$next_link = "<a href=\"".$PHP_SELF."?pagina=".$next."\">Próxima";
} else { // senão não há link para a próxima página
$next_link = "Próxima";
}

// vamos arredondar para o alto o número de páginas que serão necessárias para exibir todos os registros. Por exemplo, se temos 20 registros e mostramos 6 por página, nossa variável $total_paginas será igual a 20/6, que resultará em 3.33. Para exibir os 2 registros restantes dos 18 mostrados nas primeiras 3 páginas (0.33), será necessária a quarta página. Logo, sempre devemos arredondar uma fração de número real para um inteiro de cima e isto é feito com a função ceil().
$total_paginas = ceil($total_paginas);
$painel = "";
for ($x=1; $x<=$total_paginas; $x++) {
  if ($x==$pagina) { // se estivermos na página corrente, não exibir o link para visualização desta página
    $painel .= " [".$x."] ";
  } else {
    $painel .= " <a href=\"".$PHP_SELF."?pagina=".$x."\">[".$x."]</a>";
  }
}


// exibir painel na tela
echo " ".$prev_link." | ".$painel." | ".$next_link;
?>


</body>
</html>
