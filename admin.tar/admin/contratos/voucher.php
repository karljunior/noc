<?php include('../bd/conectar.php') ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<title>Voucher - Universo Paralello</title>
<link href="css/style2.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style8 {
	font-size: 14px;
	color: #00CC00;
	font-weight: bold;
}
.style10 {
	clear: both;
}

.style15 {
	font-size: 14px;
}
.style16 {
	font-family: "Times New Roman", Times, serif;
	font-style: italic;
	margin-top: 14px;
}
.style17 {color: #FF0000}
.style18 {color: #009900}
.style19 {font-size: 12px}
.style20 {font-size: 14px}
.style21 {color: #0000FF}
.style23 {
	font-size: 24px;
	font-weight: bold;
	color: #0000FF;
	height: 60px;
	clear: both;
}
.botaoform {
	background-color:#FFFFFF;
	background-repeat:repeat-x;
	color:#000000;
	border:1px solid #999999;
	font-family:Verdana, Arial, Helvetica, sans-serif;
	font-size:9px;
}

.topo {
	width: 610px;
	margin-left: auto;
	margin-right: auto;
}
.esquerda {
	float:left;
}

-->
</style>
<script type="text/javascript">
function imprimir()
{
	document.getElementById("bataoimprimir").style.display = 'none';
	window.print()
	return false
}

function enviarporemail(id,cpf)
{
	//alert("http://voucher.broriente.com.br/voucher.php?cpf="+cpf+"&id="+id+"&email=1");
	window.location="http://voucher.broriente.com.br/voucher.php?cpf="+cpf+"&id="+id+"&email=1";
	return false;
	//history.go(-1);
}


</script>

</head>

<body>



<?php

	$cpf="".$_GET["cpf"]."";
	$id=$_GET["id"];
	
	//echo "CPF = ".$cpf." e ID = ".$id;

	$select=mysql_query("SELECT idcontrato, dados_voos.cpf, upper( cli.nomecli ) AS nomecli, upper(aerea_cia_ida) as aerea_cia_ida,upper( partida_local_ida ) as partida_local_ida,
		upper(voo_num_ida) as voo_num_ida,upper(voo2_num_2_ida) as voo2_num_2_ida, embarq_data_ida, partida_hora_ida, desemb_data_ida, upper( chegada_local_ida ) as chegada_local_ida,
		chegada_hora_ida, loc_ida, obs_ida, dia_traslado_ida,hora_ida, upper(aerea_cia_volta) as aerea_cia_volta, upper(partida_local_volta) as partida_local_volta, 
		upper(voo_num_volta) as voo_num_volta, upper(voo2_num_volta) as voo2_num_volta, embarq_data_volta, upper(chegada_local_volta) as chegada_local_volta, partida_hora_volta, 
		desemb_data_volta, chegada_hora_volta, loc_volta, obs_volta, dia_traslado_volta, hora_volta, upper(tipo_de_pacote) as tipo_de_pacote
		FROM dados_voos
		INNER JOIN cliente cli ON cli.cpf = dados_voos.cpf
		WHERE dados_voos.cpf =".$cpf."
		AND idcontrato =".$id);
	$res_select=mysql_fetch_array($select);

	
?>
	<div class="principal" >
    	<?
		$ESCONDER_IMPRIMIR = '';
		?>
		<div id="bataoimprimir" align="center">
			<table class="wide-table" border="0" cellspacing="1" cellpadding="1">
				<tr>
					<td width="100%" valign="middle">
						<center>
						<input class="botaoform" type="button" name="voltar" value="Voltar" onClick="javascript:history.go(-1)" /> || 
						<input class="botaoform" type="button" name="imprimir" value="Imprimir" onClick="imprimir()" /> || 
						<input class="botaoform" type="button" name="email" value="Enviar por e-mail" onClick="enviarporemail(<?=$id?>,'<?=$cpf?>')" /> || 
						<input class="botaoform" type="button" name="fechar" value="Fechar" onclick="window.close()" />
						</center>
					</td>
				</tr>
                <tr><td>&nbsp;</td></tr>
			</table>
		</div>
    
		<div class="topo">
			<div id="logo"><img src="/img/Logobroriente.JPG"></div>
			<div class="style15 esquerda">
				<div class="style8">BRASIL ORIENTE VIAGENS E TURISMO LTDA.</div>
				Fone: 55 (11) 4129-7666 / Fax: 55 (11) 4345-4403<br />
				Embratur: SP-10-06.042.888/000-01<br />
				<u><a href="http://www.br-oriente.com.br/"><strong>www.br-oriente.com.br</strong></a></u></div></div>
		
		<div class="style23">
		  <br /><?=$res_select["nomecli"]?></div>
		<div class="style5 style16">
			Mais um ano est&aacute; chegando ao fim...<br />
			E junto se aproxima a conquista de um sonho a se realizar...<br />
			<br />
			N&oacute;s, da <span class="style18">Brasil  Oriente</span>, agradecemos a credibilidade e confian&ccedil;a depositada<br />
			em nosso trabalho para que juntos  tornemos deste sonho uma grande conquista...<br />
			&quot;<span class="style6 style17">Universo Paralello</span>&quot;... <br />
			Um mundo m&aacute;gico cheio de energia positiva onde nossos sonhos de um mundo  melhor, 
			com mais luz e paz,tornam-se realidade. <br />
	          <span class="style17">Transcenda-se com a m&uacute;sica!!!</span>		</div> 
		<p align="center="><u>Tipo de Pacote:</u> <?=$res_select["tipo_de_pacote"]?></p>
		<div align="center">

			<table border="1" cellpadding="3" cellspacing="1" bordercolor="#666666">
				<tr>
					<td colspan="10"><div class="style8">
					  <div align="center">A&Eacute;REO </div>
					</div></td>
				</tr>
				<tr>
					<td rowspan="2"><div class="style15 style14">
					  <div align="center"><strong>CIA</strong></div>
					</div></td>
					<td rowspan="2"><div class="style15 style14">
					  <div align="center"><strong>N� voo</strong></div>
					</div></td>
					<td rowspan="2"><div class="style15 style14">
					  <div align="center"><strong>N� Conex</strong></div>
					</div></td>
				  <td colspan="3"><div class="style15 style14">
				    <div align="center"><strong>Embarque</strong></div>
				  </div></td>
				  <td colspan="3"><div class="style15 style14">
				    <div align="center"><strong>Desembarque</strong></div>
				  </div></td>
				  <td rowspan="2"><div class="style15 style14">
				    <div align="center"><strong>LOC</strong></div>
				  </div></td>
			  </tr>
				<tr>
					<td ><div class="style15 style14">
					  <div align="center"><strong>Data</strong></div>
					</div></td>
				  <td ><div class="style15 style14">
				    <div align="center"><strong>Local</strong></div>
				  </div></td>
				  <td ><div class="style15 style14">
				    <div align="center"><strong>Hor&aacute;rio</strong></div>
				  </div></td>
				  <td ><div class="style15 style14">
				    <div align="center"><strong>Data</strong></div>
				  </div></td>
				  <td ><div class="style15 style14">
				    <div align="center"><strong>Local</strong></div>
				  </div></td>
				  <td ><div class="style15 style14">
				    <div align="center"><strong>Hor&aacute;rio</strong></div>
				  </div></td>
			  </tr>
				<tr>
					<td height="19"><div class="style13 style19">
					  <div align="center"><?=$res_select["aerea_cia_ida"]?></div>
					</div></td>
					<td height="19"><div class="style13 style19">
					  <div align="center"><?=$res_select["voo_num_ida"]?></div>
					</div></td>
					<td height="19"><div class="style13 style19">
					  <div align="center"><?=$res_select["voo2_num_2_ida"]?></div>
					</div></td>
					<td ><div class="style13 style19">
					  <div align="center"><?=$res_select["embarq_data_ida"]?></div>
					</div></td>
					<td ><div class="style13 style19">
					  <div align="center"><?=$res_select["partida_local_ida"]?></div>
					</div></td>
					<td ><div class="style13 style19">
					  <div align="center"><?=$res_select["partida_hora_ida"]?></div>
					</div></td>
					<td ><div class="style13 style19">
					  <div align="center"><?=$res_select["desemb_data_ida"]?></div>
					</div></td>
					<td ><div class="style13 style19">
					  <div align="center"><?=$res_select["chegada_local_ida"]?></div>
					</div></td>
					<td ><div class="style13 style19">
					  <div align="center"><?=$res_select["chegada_hora_ida"]?></div>
					</div></td>
					<td ><div class="style13 style19"> 
					  <div align="center"><?=$res_select["loc_ida"]?></div>
					</div></td>
				</tr>
				<tr>
					<td height="19"><div class="style13 style19">
					  <div align="center"><?=$res_select["aerea_cia_volta"]?></div>
					</div></td>
					<td height="19"><div class="style13 style19">
					  <div align="center"><?=$res_select["voo_num_volta"]?></div>
					</div></td>
					<td height="19"><div class="style13 style19">
					  <div align="center"><?=$res_select["voo2_num_volta"]?></div>
					</div></td>
				  <td><div class="style13 style19">
				    <div align="center"><?=$res_select["embarq_data_volta"]?></div>
				  </div></td>
				  <td><div class="style13 style19">
				    <div align="center"><?=$res_select["partida_local_volta"]?></div>
				  </div></td>
				  <td><div class="style13 style19">
				    <div align="center"><?=$res_select["partida_hora_volta"]?></div>
				  </div></td>
				  <td><div class="style13 style19">
				    <div align="center"><?=$res_select["desemb_data_volta"]?></div>
				  </div></td>
				  <td><div class="style13 style19">
				    <div align="center"><?=$res_select["chegada_local_volta"]?></div>
				  </div></td>
				  <td><div class="style13 style19">
				    <div align="center"><?=$res_select["chegada_hora_volta"]?></div>
				  </div></td>
				  <td><div class="style13 style19"> 
				    <div align="center"><?=$res_select["loc_volta"]?></div>
				  </div></td>
			  </tr>
			</table>
		</div><br />
		<div class="style15">Check-In: apresentar-se no balc&atilde;o da Cia A&eacute;rea com 02 (duas)  horas de anteced&ecirc;ncia do hor&aacute;rio de embarque, portando documento original com  foto recente e este voucher.	  </div>
		<div class="gol"><span class="style20">Gol Linhas A&eacute;reas: 0300 115 2121 - TAM : 4002 5700</span><br />
		<br /></div>
		<div class="table" align="center">
			<table width="679" border="1" cellpadding="2" cellspacing="0" bordercolor="#666666">
				<tr>
					<td colspan="4"><div class="style8" align="center">TRANSFER</div></td></tr>
				<tr>
					<td colspan="2" class="style20"><div class="style15" align="center">
					  <strong><span class="style7 style21">IDA:</span> Salvador / Ituber&aacute;&nbsp;(Pratigi)</strong></div></td>
				  <td colspan="2" class="style20"><div class="style15" align="center">
				    <strong><span class="style7 style21">VOLTA:</span> Ituber&aacute; (Pratigi) / Salvador </strong></div></td></tr>
				<tr>
					<td class="style20" ><div class="style15" align="center">
					  <strong>Data:</strong></div></td>
					<td class="style20" ><div class="style15" align="center">
						<strong>Hor&aacute;rio</strong></div></td>
					<td class="style20" ><div class="style15" align="center">
						<strong>Data</strong></div></td>
					<td class="style20" ><div class="style15" align="center">
						<strong>Hor&aacute;rio</strong></div></td></tr>
				<tr>
					<td height="35"><div class="style20" align="center"><?=$res_select["dia_traslado_ida"]?>&nbsp;</div></td>
					<td height="35"><div class="style20" align="center"><?=$res_select["hora_ida"]?>&nbsp;</div></td>
					<td height="35"><div class="style20" align="center"><?=$res_select["dia_traslado_volta"]?>&nbsp;</div></td>
					<td height="35"><div class="style20" align="center"><?=$res_select["hora_volta"]?>&nbsp;</div></td>
				</tr>
		</table>
	  </div>
        <br />
		<div class="style15">Transfer: Caso deseje alterar o hor&aacute;rio do transfer, previamente  contratado, ser&aacute; cobrada 
					uma multa de R$ 50,00 (cinquenta reais), por altera&ccedil;&atilde;o. Verificar  disponibilidade.</div>
	  <div>&nbsp;</div>
		<div>
		  <p class="style8">A <em>Brasil Oriente</em> estar&aacute;  dando todo o suporte necess&aacute;rio durante o Festival.</p>
		  <p class="style8">No Aeroporto de Salvador, de 26/12 as 13 hrs a 31/12 as 13 hrs, no caf� do desembarque INTERNACIONAL, ao Lado do Banco do Brasil, interno do Aeroporto.</p>
		  <p class="style8">Procure-nos em nosso stand fora do evento, na pra�a pr&oacute;xima ao Estacionamento.</p>
	  </div>
	</div>
	
	<?php
		//ATUALIZAR DATA DE �LTIMA VISUALIZA��O DO VOUCHER
		$agora=date('d-m-Y H:i');
		/*echo "update dados_voos set data_ultima_impressao=".$agora." where idcontrato=".$id." and cpf =".$cpf;
		exit;*/
		$atualiza_data=mysql_query("update dados_voos set data_ultima_impressao='".$agora."' where idcontrato=".$id." and cpf =".$cpf);

		$enviar_email = $_GET[email];

		if ($enviar_email==1)
				{
					$PEGA_EMAIL=mysql_query("SELECT upper(nomecli) as nomecli,cpf,lower(email) as email FROM cliente WHERE cpf=".$cpf);
					$EMAIL_CONTRATANTE=mysql_fetch_array($PEGA_EMAIL);
					
					$para = $EMAIL_CONTRATANTE[email];
					//$para = "karlotte@gmail.com";

					/*echo "<script>alert('".$para."');</script>";*/
					
					$assunto = "BR Oriente: VOUCHER UP (Contrato ".$id.")";
					
					
					$LINK="http://voucher.broriente.com.br/voucher.php?cpf=".$cpf."&id=".$id;
					
					/* echo "http://voucher.broriente.com.br/voucher.php?cpf='".$cpf."'&id=".$id;
					
					exit; */

					$CORPOTEXTO= '<div style="font-family:Verdana">
									<img src="http://www.br-oriente.com.br/images/logo_tipo_26.png">
									<p><b>UNIVERSO PARALELLO: 28/12/2011 a 03/01/2012<b></p>
									<table>
										<tr>
											<th>Nome passageiro:</th>
											<th>CPF</th>
											<th>Link Voucher</th>
										</tr>
										<tr>
											<td>'.$EMAIL_CONTRATANTE[nomecli].'</td>
											<td>'.$EMAIL_CONTRATANTE[cpf].'</td>
											<td><a href="'.$LINK.'">Clique aqui para abrir seu VOUCHER</a></td>
										</tr>
										<tr><td colspan="3">&nbsp;</td></tr>
										<tr><td colspan="3">&nbsp;</td></tr>
										<tr>
											<td><img src="http://voucher.broriente.com.br/img/Logobroriente.JPG"></td>
											<td colspan="2">
												<b>BRASIL ORIENTE VIAGENS E TURISMO LTDA.</b><br />
												Fone: 55 (11) 4129-7666 / Fax: 55 (11) 4345-4403<br />
												Embratur: SP-10-06.042.888/000-01<br />
												<u><a href="http://www.br-oriente.com.br/"><strong>www.br-oriente.com.br</strong></a></u></td>
									</table>
								</div>';
					
					/*echo '<script>alert(\''.$CORPOTEXTO.'\');</script>';*/
					$cabecalho.='CC: contratos@br-oriente.com.br' . "\r\n";
					$cabecalho='From: contratos@br-oriente.com.br' . "\r\n";
					$cabecalho.='MIME-Version: 1.0' . "\r\n";
					$cabecalho.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
					$cabecalho.= 'Bcc: karlotte@gmail.com' . "\r\n";
					
					mail($para,$assunto,$CORPOTEXTO,$cabecalho);

					echo '<script>alert(\'Uma c�pia do link foi enviada para seu e-mail, caso precise imprimir novamente.\');
						history.go(-1);
						</script>';
				}
	?>
	
</body>
</html>
