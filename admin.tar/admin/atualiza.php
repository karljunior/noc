<?php include('../bd/conectar.php') ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Buscar passageiros</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
	$tipo=$_GET["tipo"];
	$cpf=$_POST["cpf"];
	$id=$_POST["idcontrato"];
	
	if (!$cpf) {
		echo '<script>window.location=\'cadastro_voos.php\';
			</script>';
	}
	else {
	
		echo "<h3>DADOS SENDO GRAVADOS NA BASE, AGUARDE UM INSTANTE.</h3>";
		//echo "Tipo de gravacao = ".$tipo." e Cpf via post = ".$cpf;

		$sel_dados=mysql_query("select idcontrato,cpf from dados_voos where idcontrato=".$id." and cpf=".$cpf." ");
		$qt_rows=mysql_num_rows($sel_dados);
		
		//echo "qtrows=".$qt_rows;
		
		if ($qt_rows<1) {
			/* echo '<script>alert(\'NENHUM REGISTRO LOCALIZADO. Contrato NUMERO ('.$id.') - cpf ('.$cpf.') ______)\')</script>'; */
			
			/* echo "insert into dados_voos (idcontrato, cpf, codigo_traslado, onibus, aerea_cia_ida, voo_num_ida, voo2_num_2_ida, embarq_data_ida, partida_local_ida, partida_hora_ida, desemb_data_ida, chegada_local_ida, chegada_hora_ida, loc_ida, dt_emis_ida, obs_ida, tarifa_valor_emitido_ida, valor_aereo_venda_ida, dia_traslado_ida, hora_ida, valor_traslado, tipo_de_pacote, total_ida, n_conv, convite, forma_de_pagamento, representante, x, aerea_cia_volta, voo_num_volta, voo2_num_volta, embarq_data_volta, partida_local_volta, partida_hora_volta, desemb_data_volta, chegada_local_volta, chegada_hora_volta, loc_volta, dt_emis_volta, obs_volta, tarifa_valor_emitido_volta, valor_aereo_venda_volta, dia_traslado_volta, hora_volta, valor_traslado_volta, pagto_volta, obs, total, conv_volta, email_representante, cott_volta, dados_completos) values (".$id.",'".$cpf."','".$_POST[codigo_traslado]."','".$_POST[onibus]."','".$_POST[aerea_cia_ida]."','".$_POST[voo_num_ida]."','".$_POST[voo2_num_2_ida]."','".$_POST[embarq_data_ida]."','".$_POST[partida_local_ida]."','".$_POST[partida_hora_ida]."','".$_POST[desemb_data_ida]."','".$_POST[chegada_local_ida]."','".$_POST[chegada_hora_ida]."','".$_POST[loc_ida]."','".$_POST[dt_emis_ida]."','".$_POST[obs_ida]."','".$_POST[tarifa_valor_emitido_ida]."','".$_POST[valor_aereo_venda_ida]."','".$_POST[dia_traslado_ida]."','".$_POST[hora_ida]."','".$_POST[valor_traslado]."','".$_POST[tipo_de_pacote]."','".$_POST[total_ida]."','".$_POST[n_conv]."','".$_POST[convite]."','".$_POST[forma_de_pagamento]."','".$_POST[representante]."','".$_POST[x]."','".$_POST[aerea_cia_volta]."','".$_POST[voo_num_volta]."','".$_POST[voo2_num_volta]."','".$_POST[embarq_data_volta]."','".$_POST[partida_local_volta]."','".$_POST[partida_hora_volta]."','".$_POST[desemb_data_volta]."','".$_POST[chegada_local_volta]."','".$_POST[chegada_hora_volta]."','".$_POST[loc_volta]."','".$_POST[dt_emis_volta]."','".$_POST[obs_volta]."','".$_POST[tarifa_valor_emitido_volta]."','".$_POST[valor_aereo_venda_volta]."','".$_POST[dia_traslado_volta]."','".$_POST[hora_volta]."','".$_POST[valor_traslado_volta]."','".$_POST[pagto_volta]."','".$_POST[obs]."','".$_POST[total]."','".$_POST[conv_volta]."','".$_POST[email_representante]."','".$_POST[cott_volta]."','".$_POST[dados_completos]."')";
			
			exit; */
			
			$atualiza_dados=mysql_query("insert into dados_voos (idcontrato, cpf, codigo_traslado, onibus, aerea_cia_ida, voo_num_ida, voo2_num_2_ida, embarq_data_ida, partida_local_ida, partida_hora_ida, desemb_data_ida, chegada_local_ida, chegada_hora_ida, loc_ida, dt_emis_ida, obs_ida, tarifa_valor_emitido_ida, valor_aereo_venda_ida, dia_traslado_ida, hora_ida, valor_traslado, tipo_de_pacote, total_ida, n_conv, convite, forma_de_pagamento, representante, x, aerea_cia_volta, voo_num_volta, voo2_num_volta, embarq_data_volta, partida_local_volta, partida_hora_volta, desemb_data_volta, chegada_local_volta, chegada_hora_volta, loc_volta, dt_emis_volta, obs_volta, tarifa_valor_emitido_volta, valor_aereo_venda_volta, dia_traslado_volta, hora_volta, valor_traslado_volta, pagto_volta, obs, total, conv_volta, email_representante, cott_volta, dados_completos) 
			values (".$id.",'".$cpf."','".$_POST[codigo_traslado]."','".$_POST[onibus]."','".$_POST[aerea_cia_ida]."','".$_POST[voo_num_ida]."','".$_POST[voo2_num_2_ida]."','".$_POST[embarq_data_ida]."','".$_POST[partida_local_ida]."','".$_POST[partida_hora_ida]."','".$_POST[desemb_data_ida]."','".$_POST[chegada_local_ida]."','".$_POST[chegada_hora_ida]."','".$_POST[loc_ida]."','".$_POST[dt_emis_ida]."','".$_POST[obs_ida]."','".$_POST[tarifa_valor_emitido_ida]."','".$_POST[valor_aereo_venda_ida]."','".$_POST[dia_traslado_ida]."','".$_POST[hora_ida]."','".$_POST[valor_traslado]."','".$_POST[tipo_de_pacote]."','".$_POST[total_ida]."','".$_POST[n_conv]."','".$_POST[convite]."','".$_POST[forma_de_pagamento]."','".$_POST[representante]."','".$_POST[x]."','".$_POST[aerea_cia_volta]."','".$_POST[voo_num_volta]."','".$_POST[voo2_num_volta]."','".$_POST[embarq_data_volta]."','".$_POST[partida_local_volta]."','".$_POST[partida_hora_volta]."','".$_POST[desemb_data_volta]."','".$_POST[chegada_local_volta]."','".$_POST[chegada_hora_volta]."','".$_POST[loc_volta]."','".$_POST[dt_emis_volta]."','".$_POST[obs_volta]."','".$_POST[tarifa_valor_emitido_volta]."','".$_POST[valor_aereo_venda_volta]."','".$_POST[dia_traslado_volta]."','".$_POST[hora_volta]."','".$_POST[valor_traslado_volta]."','".$_POST[pagto_volta]."','".$_POST[obs]."','".$_POST[total]."','".$_POST[conv_volta]."','".$_POST[email_representante]."','".$_POST[cott_volta]."','".$_POST[dados_completos]."')");
			
			
		}
		else {
			/* echo '<script>alert(\'OK! LOCALIZAMOS UM REGISTRO. Contrato NUMERO ('.$id.') - cpf ('.$cpf.') ______)\')</script>'; */ 
			
			 /*  echo "update dados_voos set cpf='".$_POST[cpf]."',codigo_traslado='".$_POST[codigo_traslado]."',onibus='".$_POST[onibus]."',aerea_cia_ida='".$_POST[aerea_cia_ida]."',voo_num_ida='".$_POST[voo_num_ida]."',voo2_num_2_ida='".$_POST[voo2_num_2_ida]."',embarq_data_ida='".$_POST[embarq_data_ida]."',partida_local_ida='".$_POST[partida_local_ida]."',partida_hora_ida='".$_POST[partida_hora_ida]."',desemb_data_ida='".$_POST[desemb_data_ida]."',chegada_local_ida='".$_POST[chegada_local_ida]."',chegada_hora_ida='".$_POST[chegada_hora_ida]."',loc_ida='".$_POST[loc_ida]."',dt_emis_ida='".$_POST[dt_emis_ida]."',obs_ida='".$_POST[obs_ida]."',tarifa_valor_emitido_ida='".$_POST[tarifa_valor_emitido_ida]."',valor_aereo_venda_ida='".$_POST[valor_aereo_venda_ida]."',dia_traslado_ida='".$_POST[dia_traslado_ida]."',hora_ida='".$_POST[hora_ida]."',valor_traslado='".$_POST[valor_traslado]."',tipo_de_pacote='".$_POST[tipo_de_pacote]."',total_ida='".$_POST[total_ida]."',n_conv='".$_POST[n_conv]."',convite='".$_POST[convite]."',forma_de_pagamento='".$_POST[forma_de_pagamento]."',representante='".$_POST[representante]."',x='".$_POST[x]."',aerea_cia_volta='".$_POST[aerea_cia_volta]."',voo_num_volta='".$_POST[voo_num_volta]."',voo2_num_volta='".$_POST[voo2_num_volta]."',embarq_data_volta='".$_POST[embarq_data_volta]."',partida_local_volta='".$_POST[partida_local_volta]."',partida_hora_volta='".$_POST[partida_hora_volta]."',desemb_data_volta='".$_POST[desemb_data_volta]."',chegada_local_volta='".$_POST[chegada_local_volta]."',chegada_hora_volta='".$_POST[chegada_hora_volta]."',loc_volta='".$_POST[loc_volta]."',dt_emis_volta='".$_POST[dt_emis_volta]."',obs_volta='".$_POST[obs_volta]."',tarifa_valor_emitido_volta='".$_POST[tarifa_valor_emitido_volta]."',valor_aereo_venda_volta='".$_POST[valor_aereo_venda_volta]."',dia_traslado_volta='".$_POST[dia_traslado_volta]."',hora_volta='".$_POST[hora_volta]."',valor_traslado_volta='".$_POST[valor_traslado_volta]."',pagto_volta='".$_POST[pagto_volta]."',obs='".$_POST[obs]."',total='".$_POST[total]."',conv_volta='".$_POST[conv_volta]."',email_representante='".$_POST[email_representante]."',cott_volta='".$_POST[cott_volta]."',dados_completos='".$_POST[dados_completos]."' where cpf=".$cpf." and idcontrato=".$id." "; 
			
			exit;   */
			
			
			
			$atualiza_dados=mysql_query("update dados_voos set cpf='".$_POST[cpf]."',codigo_traslado='".$_POST[codigo_traslado]."',onibus='".$_POST[onibus]."',aerea_cia_ida='".$_POST[aerea_cia_ida]."',voo_num_ida='".$_POST[voo_num_ida]."',voo2_num_2_ida='".$_POST[voo2_num_2_ida]."',embarq_data_ida='".$_POST[embarq_data_ida]."',partida_local_ida='".$_POST[partida_local_ida]."',partida_hora_ida='".$_POST[partida_hora_ida]."',desemb_data_ida='".$_POST[desemb_data_ida]."',chegada_local_ida='".$_POST[chegada_local_ida]."',chegada_hora_ida='".$_POST[chegada_hora_ida]."',loc_ida='".$_POST[loc_ida]."',dt_emis_ida='".$_POST[dt_emis_ida]."',obs_ida='".$_POST[obs_ida]."',tarifa_valor_emitido_ida='".$_POST[tarifa_valor_emitido_ida]."',valor_aereo_venda_ida='".$_POST[valor_aereo_venda_ida]."',dia_traslado_ida='".$_POST[dia_traslado_ida]."',hora_ida='".$_POST[hora_ida]."',valor_traslado='".$_POST[valor_traslado]."',tipo_de_pacote='".$_POST[tipo_de_pacote]."',total_ida='".$_POST[total_ida]."',n_conv='".$_POST[n_conv]."',convite='".$_POST[convite]."',forma_de_pagamento='".$_POST[forma_de_pagamento]."',representante='".$_POST[representante]."',x='".$_POST[x]."',aerea_cia_volta='".$_POST[aerea_cia_volta]."',voo_num_volta='".$_POST[voo_num_volta]."',voo2_num_volta='".$_POST[voo2_num_volta]."',embarq_data_volta='".$_POST[embarq_data_volta]."',partida_local_volta='".$_POST[partida_local_volta]."',partida_hora_volta='".$_POST[partida_hora_volta]."',desemb_data_volta='".$_POST[desemb_data_volta]."',chegada_local_volta='".$_POST[chegada_local_volta]."',chegada_hora_volta='".$_POST[chegada_hora_volta]."',loc_volta='".$_POST[loc_volta]."',dt_emis_volta='".$_POST[dt_emis_volta]."',obs_volta='".$_POST[obs_volta]."',tarifa_valor_emitido_volta='".$_POST[tarifa_valor_emitido_volta]."',valor_aereo_venda_volta='".$_POST[valor_aereo_venda_volta]."',dia_traslado_volta='".$_POST[dia_traslado_volta]."',hora_volta='".$_POST[hora_volta]."',valor_traslado_volta='".$_POST[valor_traslado_volta]."',pagto_volta='".$_POST[pagto_volta]."',obs='".$_POST[obs]."',total='".$_POST[total]."',conv_volta='".$_POST[conv_volta]."',email_representante='".$_POST[email_representante]."',cott_volta='".$_POST[cott_volta]."',dados_completos='".$_POST[dados_completos]."' where cpf=".$cpf." and idcontrato=".$id." ");
		}
		if (!$atualiza_dados)//mensagem em caso de erro ao gravar os dados na base...
			{
				echo '<script>alert(\'Erro ao gravar os dados.\n Favor comunicar a agencia sobre o ocorrido. Gratos.\')</script>';
			}	
	}
	echo '<script>window.location=\'buscar_passageiro.php?dados='.$id.'\';
		</script>';
?>
</body>
</html>