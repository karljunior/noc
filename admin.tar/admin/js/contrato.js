function validaForm()
{

	d = document.contrato;
	
	//validar pacote
	variavel=document.contrato.pct;
	if (variavel.value=="")
	{
		alert('Selecione um Pacote.');
		variavel.focus();
		return false;
	}

	//validar local de saida 
	variavel=document.contrato.uf;
	if (variavel.value=="")
	{
		alert('Selecione um local de origem');
		variavel.focus();
		return false;
	}


	//VALIDAÇÃO: Não permitir seguir sem escolher ao menos Data de Ida ou Data de Volta
	variavel=document.contrato;
	if (variavel.dt_ida.value=="" && variavel.dt_chegada.value=="")
	{
		alert('Escolha a Data de Embarque IDA para pacote apenas de ida, \n Data de Embarque VOLTA para pacote apenas de volta ou \n As duas para pacote completo (IDA e VOLTA).');
		variavel.dt_ida.focus();
		return false;
	}
	
	//Validar opção com traslado
	if (variavel.pct.value==1)
	{
		if (variavel.dt_ida.value!="" && variavel.traslado_ida.value=="")
		{
			alert('Voce escolheu uma data para embarque de IDA, mas nao selecionou a data/horario do traslado. \nPor favor, escolha uma.');
			variavel.traslado_ida.focus();
			return false;
		}
		
		if (variavel.dt_chegada.value!="" && variavel.traslado_volta.value=="")
		{
			alert('Voce escolheu uma data para embarque de Retorno, mas nao selecionou a data/horario do traslado. \nPor favor, escolha uma.');
			variavel.traslado_volta.focus();
			return false;
		}
	}


	//validar Representante
	if (d.representante.value == "")
	{
		alert("Escolha o Representante que lhe atendeu.");
		d.representante.focus();
		return false;
	}


	//validar TOTAL de passageiros(list)
	if (d.txtqtde_pass.value == "--")
	{
		alert("Selecione o Total de passageiros do contrato.");
		d.txtqtde_pass.focus();
		return false;
	}


	//validar Aceite de contrato
	if (document.contrato.chkcondicoes.checked==false)
	{
		alert('Favor ler e aceitar as condicoes contratuais.');
		document.contrato.chkcondicoes.focus();
		return false;
	}
	
	//validar nome
	if (d.txtnomecontrato.value == "")
	{
		alert("O campo Nome deve ser preenchido.");
		d.txtnomecontrato.focus();
		return false;
	}

	//validar data de nascimento
	if (d.txtdtnascto.value == "")
	{
		alert("O campo data de nascimento deve ser preenchido.");
		d.txtdtnascto.focus();
		return false;
	}


	//validar CPF
	if (d.txtcpf.value == "")
	{
		alert("O campo CPF deve ser preenchido.");
		d.txtcpf.focus();
		return false;
	}
	else
	{
		var cpf = d.txtcpf.value;
		//alert("CPF = "+cpf);
		
		cpf = cpf.replace("-","");
		cpf = cpf.replace(".","");
		cpf = cpf.replace(".","");
		
		erro = new String;
		if (cpf.length < 11) erro += "Sao necessarios 11 digitos para verificacao do CPF! \n\n";
		var nonNumbers = /\D/;
		if (nonNumbers.test(cpf)) erro += "A verificacao de CPF suporta apenas numeros! \n\n";
		if (cpf == "00000000000" || cpf == "11111111111" || cpf == "22222222222" || cpf == "33333333333" || cpf == "44444444444" || cpf == "55555555555" || cpf == "66666666666" || cpf == "77777777777" || cpf == "88888888888" || cpf == "99999999999"){
			 erro += "Numero de CPF invalido!"
		}
		var a = [];
		var b = new Number;
		var c = 11;
		for (i=0; i<11; i++){
		   a[i] = cpf.charAt(i);
		   if (i < 9) b += (a[i] * --c);
		}
		if ((x = b % 11) < 2) { a[9] = 0 } else { a[9] = 11-x }
		b = 0;
		c = 11;
		for (y=0; y<10; y++) b += (a[y] * c--);
		if ((x = b % 11) < 2) { a[10] = 0; } else { a[10] = 11-x; }
		if ((cpf.charAt(9) != a[9]) || (cpf.charAt(10) != a[10])){
		   erro +="CPF informado invalido!";
		}
		if (erro.length > 0){
		   alert(erro);
		   d.txtcpf.focus();
		   return false;
		}
		//return true;
	}
	

	//validar RG
	if (d.txtrg.value == "")
	{
		alert("O campo RG deve ser preenchido.");
		d.txtrg.focus();
		return false;
	}

	//validar EXP
	if (d.txtexp.value == "")
	{
		alert("O campo EXP deve ser preenchido.");
		d.txtexp.focus();
		return false;
	}

	//TELEFONE RESIDENCIAL
	if (d.txttelresid.value == "")
	{
		alert("O campo Telefone Residencial deve ser preenchido.");
		d.txttelresid.focus();
		return false;
	}

	//celular
	if (d.txtcel.value == "")
	{
		alert("O campo Telefone Celular deve ser preenchido.");
		d.txtcel.focus();
		return false;
	}

	//Email
	if (d.txtmail.value == "")
	{
		alert("O campo Email deve ser preenchido.");
		d.txtmail.focus();
		return false;
	}

	//Nome da Mãe
	if (d.txtfiliacao02.value == "")
	{
		alert("O campo Filiacao Materna deve ser preenchido.");
		d.txtfiliacao02.focus();
		return false;
	}

	//Endereço
	if (d.txtend.value == "")
	{
		alert("Informe seu Endereço residencial.");
		d.txtend.focus();
		return false;
	}


	//Número
	if (d.txtnumero.value == "")
	{
		alert("Informe o Número de seu endereço residencial.");
		d.txtnumero.focus();
		return false;
	}

	//CEP
	if (d.txtcep.value == "")
	{
		alert("Informe o CEP de sua casa.");
		d.txtcep.focus();
		return false;
	}

	//Bairro
	if (d.txtbairro.value == "")
	{
		alert("Informe o Bairro de seu endereço residencial.");
		d.txtbairro.focus();
		return false;
	}

	//Cidade
	if (d.txtmunicipio.value == "")
	{
		alert("Informe a Cidade de seu endereço residencial.");
		d.txtmunicipio.focus();
		return false;
	}



	//UF 
	if (d.menu1.value == "")
	{
		alert("O campo UF de residencia deve ser preenchido.");
		d.menu1.focus();
		return false;
	}


	//validar data de nascimento
	erro=0;
	hoje = new Date();
	anoAtual = hoje.getFullYear();
	barras = d.txtdtnascto.value.split("/");

	if (barras.length == 3)
	{
		dia = barras[0];
		mes = barras[1];
		ano = barras[2];
		resultado = (!isNaN(dia) && (dia > 0) && (dia < 32)) && (!isNaN(mes) && 
		(mes > 0) && (mes < 13)) && (!isNaN(ano) && (ano.length == 4) && (ano <= anoAtual && ano >= 1900));
		if (!resultado) {
		alert("Formato de data de nascimento invalido.");
		d.txtdtnascto.focus();
		return false;
		}

	} else 
	{
		alert("Formato de data de nascimento invalido.");
		d.txtdtnascto.focus();
		return false;
	}

return true;

}

 
function ValidaFormCheque()
{
		//VALIDAR CAMPOS DA PAGINA DE CHEQUES
		formcheque=document.cheque;
        if (formcheque.txtbanco.value == "")
		{
			alert("Favor informar o nome do banco.");
			formcheque.txtbanco.focus();
			return false;
		}

        if (formcheque.txtagencia.value == "")
		{
			alert("Favor informar o número da agência.");
			formcheque.txtagencia.focus();
			return false;
		}
        if (formcheque.txtcc.value == "")
		{
			alert("Favor informar o número da conta corrente.");
			formcheque.txtcc.focus();
			return false;
		}	
	
}
 

//desabilita texto

function nu(campo){

var digits="0123456789"

var campo_temp 

for (var i=0;i<campo.value.length;i++){

campo_temp=campo.value.substring(i,i+1) 

if (digits.indexOf(campo_temp)==-1){

campo.value = campo.value.substring(0,i);

break;

}

}

}


			function FormataCpf(campo, teclapres)
			{
				var tecla = teclapres.keyCode;
				var vr = new String(campo.value);
				vr = vr.replace(".", "");
				vr = vr.replace("/", "");
				vr = vr.replace("-", "");
				tam = vr.length + 1;
				if (tecla != 14)
				{
					if (tam == 4)
						campo.value = vr.substr(0, 3) + '.';
					if (tam == 7)
						campo.value = vr.substr(0, 3) + '.' + vr.substr(3, 6) + '.';
					if (tam == 11)
						campo.value = vr.substr(0, 3) + '.' + vr.substr(3, 3) + '.' + vr.substr(7, 3) + '-' + vr.substr(11, 2);
				}
			}
	

function MM_formtCep(e,src,mask)
{
	if(window.event)
	{ 
		_TXT = e.keyCode;
	}        
	else if(e.which) 
	{
		_TXT = e.which;
	}        
	
	if(_TXT > 47 && _TXT < 58) 
	{   
		var i = src.value.length; 
		var saida = mask.substring(0,1); 
		var texto = mask.substring(i)  
		if (texto.substring(0,1) != saida) 
		{ 
			src.value += texto.substring(0,1); 
		}      
		return true; 
	}
	else 
	{ 
		if (_TXT != 8) 
		{ 
			return false; 
		}  
		else 
		{ 
			return true; 
		}        
	}
}


