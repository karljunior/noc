<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>BR Oriente - UP:: Admin</title>
    </head>

    <body>
        <div align="center">
        <?php include("menu.html"); ?>

        <p>TELA DE ADMINISTRAÇÃO DO AMBIENTE UNIVERSO PARALELO</p>
        
            <iframe name="main" frameborder="1" scrolling="auto" width="800px" height="600px"></iframe>
        </div>

        
    </body>

</html>
