<?php
include "../../bd/conectar_hmg.php";
// Cadastro de traslado
$tipooperacao = $_GET['op'];
  switch ($tipooperacao){
    case 1:
        //OPERACAÇÃO DE ADICIONAR TRASLADOS
        {
            
            //echo ("insert into data_traslado (dia,horario,tipo_traslado,habilitado) values('".$_POST['dia']."','".$_POST['horario']."',".$_POST['tipotraslado'].",1) ");
            //echo ('<script>alert(\'OPERACAO 1.\');history.go(-1);</script>;');
            
            $query ="insert into data_traslado (dia,horario,tipo_traslado,habilitado) ";
            $query.="values('".$_POST['dia']."','".$_POST['horario']."',".$_POST['tipotraslado'].",1) ";
            $res=mysql_query($query);
            mysql_close();
            if ($res == 0) {
                echo ('Erro...');
            }
            else
                echo ('<script>alert(\'Cadastrado com sucesso.\');</script>');
        }
      break;
    case 2:
        //OPERAÇÃO DE DESABILITAR TRASLADOS
        {
            //echo ('<script>alert(\'OPERACAO 2.\');</script>;');
            $query ="update data_traslado set habilitado = 0 where id_data_traslado =".$_GET['id'];
            $res=mysql_query($query);
            mysql_close();
        }
      break;
    case 3:
        //OPERAÇÃO DE HABILITAR TRASLADOS
        {
            //echo ('<script>alert(\'OPERACAO 3.\');history.go(-1);</script>;');
            $query ="update data_traslado set habilitado = 1 where id_data_traslado =".$_GET['id'];
            $res=mysql_query($query);
            mysql_close();
        }
        break;
    default:
        {
            echo ('<script>alert(\'ACESSO INCORRETO.\');</script>');
            //echo '<script>window.location=\'index.php\';</script>';
        }
        break;
  }
  echo ("<script>window.location='index.php';</script>");
?>