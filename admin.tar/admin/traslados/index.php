<?php include('../../bd/conectar_hmg.php') ?>
<!DOCTYPE HTML>
<html>
    <head>
        <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Lista Traslados</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" />
        <script src="_addtraslados.js"></script>
        <script>
            function MM_formt(e,src,mask) {
                if(window.event)
                { 
                    _TXT = e.keyCode;
                }        
                else if(e.which) 
                {
                    _TXT = e.which;
                }        
                if(_TXT > 47 && _TXT < 58) 
                {   
                    var i = src.value.length; 
                    var saida = mask.substring(0,1); 
                    var texto = mask.substring(i)  
                    if (texto.substring(0,1) != saida) 
                    { 
                        src.value += texto.substring(0,1); 
                    }      
                    return true; 
                } else
                { 
                    if (_TXT != 8) 
                    { 
                        return false; 
                    }  
                    else 
                    { 
                        return true; 
                    }        
                }
            }
        </script>
    </head>
    <body>
        <div class="principal" >
            Adicionar Traslados:
            <form name="traslados" method="post" action="update.php?op=1" onSubmit="return validaForm()" >
                Dia: <input type="text" name="dia" size="6" maxlength="5" onkeypress="return MM_formt(event,this,'##/##');">&nbsp;&nbsp;
                Horario: <input type="text" name="horario" size="6" maxlength="5" onkeypress="return MM_formt(event,this,'##:##');">&nbsp;&nbsp;
                Tipo: 
                <input type="radio" name="tipotraslado" value="0">IDA&nbsp;|&nbsp;
                <input type="radio" name="tipotraslado" value="1">VOLTA
                <input type=reset value=Limpar> <input type=submit value=Enviar>
            </form>
            <hr>
            <?php
            $Select_Traslados = "select id_data_traslado,dia,horario,case tipo_traslado when 0 then 'IDA' when 1 then 'VOLTA' end as sentido,habilitado ";
            $Select_Traslados.="from data_traslado order by 4,2,1";

            $res_busca = mysql_query($Select_Traslados);

            echo '
            <h3>Traslados: </h3>
            <table border="1" cellpadding="4" cellspacing="0" align="center">
                <tr>
                    <th width="130" valign="middle">DIA</th>
                    <th width="130" nowrap="nowrap" valign="middle">HORARIO</th>
                    <th width="130" nowrap="nowrap" valign="middle">SENTIDO</th>
                    <th>&nbsp;</th>
                </tr>';
            /* Carregar traslados na tabela--> */
            while ($escrever = mysql_fetch_array($res_busca)) {
                echo '
                <tr>
                    <td width="130" valign="middle">'.$escrever['dia'].'</td>
                    <td width="130" nowrap="nowrap" valign="middle">'.$escrever['horario'].'</td>
                    <td width="130" nowrap="nowrap" valign="middle">'.$escrever['sentido'].'</td>';

                if ($escrever['habilitado'] == 1) {
                    /* echo '<td width="55" nowrap="nowrap" valign=\"middle\"><a href="voucher.php?cpf=' . $escrever[cpf] . '&id=' . $dados . '"><img src="img/voucher.png"></a></td></tr>'; */
                    echo '<td width="55" nowrap="nowrap" valign=\"middle\"><a href="update.php?op=2&id=' . $escrever['id_data_traslado'] . '"><img src="img/desabilitar.png"></a></td></tr>';
                } else {
                    /* echo '<td width="55" nowrap="nowrap" valign=\"middle\"><a href="#"><img src="img/aguarde.png"></a></td></tr>'; */
                    echo '<td width="55" nowrap="nowrap" valign=\"middle\"><a href="update.php?op=3&id=' . $escrever['id_data_traslado'] . '"><img src="img/habilitar.png">
                        <input class="botaoform" type="button" name="desabilitar" value="Desabilitar" onClick="javascript:window.location="update.php?op=2&id='.$escrever['id_data_traslado'].'" /></td></tr>';
                }
            }
            echo ' </table> ';
            mysql_close();
            ?>
            <div><br /><br />
            </div>
        </div>
    </body>
</html>