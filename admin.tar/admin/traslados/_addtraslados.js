/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
function validaForm()
{
    d = document.traslados;
	
    //validar Dia
    variavel=d.dia;
    if (variavel.value=="")
    {
        alert('-- Informe uma data --');
        variavel.focus();
        return false;
    }

    //validar Horario
    variavel=d.horario;
    if (variavel.value=="")
    {
        alert('-- Informe um horario --');
        variavel.focus();
        return false;
    }

    //validar Tipo Traslado
    variavel=d.tipotraslado;
    if (variavel[0].checked == false && variavel[1].checked == false) 
    {
        alert('-- Selecione o tipo de traslado. IDA ou VOLTA --');
        return false;
    }
    return true;
}