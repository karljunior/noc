<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<title>Modelo POP CSS</title>
	<link href="./index_files/style2.css" rel="stylesheet" type="text/css">
	<link href="inc/estilos.css" rel="stylesheet" type="text/css" >

</head>

<body>
	<form name="incidenteOPEN" action="email.php" method="GET">
	<div>
		<div class="_leftimg"></div>
		<div class="_topo"><h4>COMUNICADO DE ALERTA/INDISPONIBILIDADE - INFRAESTRUTURA DE TI<br>SALA DE MONITORAMENTO</h4></div>
		<div class="_classe">ALERTA</div>

		<div id="_middle">
			<br>
			<table border="1">
				<tbody>
				<tr>
					<th>OCORRÊNCIA:</th><td colspan="3">
						<textarea name="ocorrencia" cols="83" rows="2">TEXTO OCORRENCIA</textarea>
					</td>
				</tr>
				<tr>
					<th>IMPACTO:</th><td colspan="3">
						<textarea name="impacto" cols="83" rows="2">TEXTO IMPACTO</textarea>
					</td>
				</tr>
				<tr>
					<th>Data/Hora início:</th><td align="center">
						<input type="datetime-local" name="datainicio" value="19/07/2013 18:00" maxlength="16">
					</td>
					<th>Data/Hora fim:</th><td align="center">
						<input type="datetime-local" name="datafim" value="19/07/2013 18:05" maxlength="16">
					</td>
				</tr>
				<tr>
					<th>Ação Esperada:</th><td colspan="3">
						<textarea name="acaoesperada" cols="83" rows="2">TEXTO ACAO ESPERADA</textarea>
					</td>
				</tr>
				<tr>
					<th>Situção Atual:</th><td colspan="3">
						<textarea name="situacaoatual" cols="83" rows="2">TEXTO SITUAÇÃO ATUAL</textarea>
					</td>
				</tr>
				<tr>
					<th>Registro de Incidente:</th><td colspan="3">
						<input type="number" value="1000" name="numincidente" />
					</td>
				</tr>
				<tr>
					<th>Evidências:</th><td colspan="3">
						<input type="file" name="evidencia" multiple=""></input>
					</td>
				</tr>
				</tbody>
			</table>
		</div>
		<br>
		
		<div class="_footer">
			<table border="1">
			<tbody>
				<tr>
					<th>Ambiente:</th><td><textarea name="ambiente" cols="30" rows="2"><<AMBIENTE>></textarea></td>
					<th>Severidade:</th><td><textarea name="severidade" cols="30" rows="2"><<SEVERIDADE>></textarea></th>
				</tr>
				<tr>
					<th>Assunto:</th><td colspan="3"><textarea name="assunto" cols="83" rows="2">TEXTO ASSUNTO</textarea></td>
				</tr>
				<tr>
					<th>Enviar PARA:</th><td colspan="3"><textarea name="para" cols="83" rows="2">TEXTO DESTINATARIOS PARA</textarea></td>
				</tr>
		
				<tr>
					<th>Com CÓPIA:</th><td colspan="3"><textarea name="copia" cols="83" rows="2">TEXTO DESTINATARIOS COPIADOS</textarea></td>
				</tr>
			</tbody>
			</table>
			<br>
			<input class="botaoform" type="button" name="Voltar" value="Voltar" onclick="javascript:history.go(-1)">&nbsp;||&nbsp;
			<input class="botaoform" type="reset" name="Limpar" value="Limpar tudo">&nbsp;||&nbsp;
			<input class="botaoform" type="submit" name="Preparar" value="Preparar e-mail">
		</div>
		
	</div>
	</form>

</body>
</html>